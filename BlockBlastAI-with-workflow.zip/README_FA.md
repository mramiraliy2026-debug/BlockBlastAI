# Block Blast AI V2 — Android Studio Build-Ready

این نسخه ساختار کامل Android Studio را دارد و فایل‌های اصلی Java و resourceها داخل پروژه قرار گرفته‌اند.

## Build
1. پوشه `BlockBlastAI` را در Android Studio با **Open** باز کن.
2. صبر کن Gradle Sync کامل شود.
3. از منوی **Build → Build APK(s)** استفاده کن.
4. APK معمولاً در `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

## اجرای روی گوشی
- Android 11 یا بالاتر
- پس از نصب، برنامه را باز کن.
- دکمه «فعال‌سازی Accessibility» را بزن.
- سرویس **Block Blast AI** را فعال کن.
- سپس Auto Play را شروع کن.

## نکته فنی
این پروژه اکنون از نظر ساختار Android قابل Build است، اما Vision و مختصات Drag برای همه نسخه‌های Block Blast یکسان نیست. برای Auto Play دقیق روی گوشی واقعی، مرحله Calibration باید بر اساس اسکرین‌شات/رزولوشن همان دستگاه تنظیم شود.
