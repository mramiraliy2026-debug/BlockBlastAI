package com.blockblast.ai;
import android.graphics.Bitmap;
import android.graphics.Color;
public final class Vision {
    public static Board readBoard(Bitmap b,int left,int top,int size){
        boolean[][] a=new boolean[8][8]; int cell=Math.max(1,size/8);
        for(int r=0;r<8;r++)for(int c=0;c<8;c++){int x=Math.min(b.getWidth()-1,left+c*cell+cell/2),y=Math.min(b.getHeight()-1,top+r*cell+cell/2);int px=b.getPixel(x,y);a[r][c]=Color.alpha(px)>0 && (Color.red(px)+Color.green(px)+Color.blue(px))<690;}
        return new Board(a);
    }
    public static Shape[] demoPieces(){return new Shape[]{new Shape(new int[][]{{0,0}}),new Shape(new int[][]{{0,0},{0,1}}),new Shape(new int[][]{{0,0},{1,0},{1,1}})};}
}
