package com.blockblast.ai;
import java.util.*;
public final class Shapes {
 public static final int[][][] SHAPES={
  {{0,0}},{{0,0},{0,1}},{{0,0},{1,0}},{{0,0},{0,1},{0,2}},{{0,0},{1,0},{2,0}},
  {{0,0},{0,1},{1,0},{1,1}},{{0,0},{1,0},{1,1}},{{0,1},{1,0},{1,1}},{{0,0},{0,1},{1,1}},{{0,0},{1,0},{1,-1}},
  {{0,0},{0,1},{0,2},{0,3}},{{0,0},{1,0},{2,0},{3,0}},{{0,0},{0,1},{0,2},{1,0},{1,1},{1,2}},{{0,0},{1,0},{2,0},{0,1},{1,1},{2,1}},
  {{0,0},{1,0},{2,0},{0,1},{0,2}},{{0,0},{0,1},{0,2},{1,2},{2,2}},{{0,0},{0,1},{1,0},{2,0},{2,1}},{{0,1},{1,1},{2,0},{2,1},{2,2}},
  {{0,0},{0,1},{0,2},{0,3},{0,4}},{{0,0},{1,0},{2,0},{3,0},{4,0}},
  {{0,0},{1,0},{1,1},{2,1}},{{0,1},{1,0},{1,1},{2,0}}
 };
 public static int[][] normalize(int[][] p){int mr=999,mc=999;for(int[]q:p){mr=Math.min(mr,q[0]);mc=Math.min(mc,q[1]);}int[][]o=new int[p.length][2];for(int i=0;i<p.length;i++){o[i][0]=p[i][0]-mr;o[i][1]=p[i][1]-mc;}Arrays.sort(o,Comparator.comparingInt((int[]q)->q[0]).thenComparingInt(q->q[1]));return o;}
 public static int[][] fromMask(boolean[][] m){ArrayList<int[]> a=new ArrayList<>();for(int r=0;r<m.length;r++)for(int c=0;c<m[0].length;c++)if(m[r][c])a.add(new int[]{r,c});if(a.isEmpty())return null;return normalize(a.toArray(new int[0][2]));}
}
