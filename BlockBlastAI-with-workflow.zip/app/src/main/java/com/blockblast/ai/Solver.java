package com.blockblast.ai;
import java.util.*;
public final class Solver {
    private static final double NEG=-1e18;
    public List<Move> solve(Board board, Shape[] pieces){
        List<Move> best=new ArrayList<>(); SearchResult r=search(board,pieces,new boolean[pieces.length],new ArrayList<>(),0); if(r.path!=null)best=r.path; return best;
    }
    private SearchResult search(Board b,Shape[] p,boolean[] used,List<Move> path,int depth){
        if(depth==p.length)return new SearchResult(score(b),new ArrayList<>(path));
        double best=NEG;List<Move> bestPath=null;
        for(int i=0;i<p.length;i++)if(!used[i]){used[i]=true;for(int r=0;r<Board.N;r++)for(int c=0;c<Board.N;c++)if(b.canPlace(p[i],r,c)){Board nb=b.place(p[i],r,c);path.add(new Move(i,r,c));SearchResult x=search(nb,p,used,path,depth+1);path.remove(path.size()-1);if(x.score>best){best=x.score;bestPath=x.path;}}used[i]=false;}
        return new SearchResult(best,bestPath);
    }
    private double score(Board b){return -b.count()*1.0 - b.maxHeight()*3.0 - b.holes()*7.0 + b.mobility(new Shape[]{new Shape(new int[][]{{0,0}})})*0.15;}
    private static final class SearchResult{final double score;final List<Move> path;SearchResult(double s,List<Move> p){score=s;path=p;}}
}
