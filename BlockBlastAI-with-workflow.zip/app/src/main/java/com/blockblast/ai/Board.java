package com.blockblast.ai;

public final class Board {
    public static final int N = 8;
    private final boolean[][] cells;
    public Board() { cells = new boolean[N][N]; }
    public Board(boolean[][] src) { cells = new boolean[N][N]; for(int r=0;r<N;r++) System.arraycopy(src[r],0,cells[r],0,N); }
    public boolean get(int r,int c){ return r>=0&&r<N&&c>=0&&c<N&&cells[r][c]; }
    public boolean canPlace(Shape s,int r,int c){ for(int[] p:s.cells){int rr=r+p[0],cc=c+p[1]; if(rr<0||rr>=N||cc<0||cc>=N||get(rr,cc)) return false;} return true; }
    public Board place(Shape s,int r,int c){ Board b=new Board(cells); for(int[] p:s.cells)b.cells[r+p[0]][c+p[1]]=true; b.clearFullLines(); return b; }
    public int count(){int n=0;for(boolean[] row:cells)for(boolean x:row)if(x)n++;return n;}
    public int holes(){int h=0;for(int r=0;r<N;r++)for(int c=0;c<N;c++)if(!cells[r][c] && (r>0&&cells[r-1][c]) && (r<N-1&&cells[r+1][c]))h++;return h;}
    public int maxHeight(){int m=0;for(int c=0;c<N;c++){int h=0;for(int r=0;r<N;r++)if(cells[r][c]){h=N-r;break;}m=Math.max(m,h);}return m;}
    public int mobility(Shape[] shapes){int n=0;for(Shape s:shapes)for(int r=0;r<N;r++)for(int c=0;c<N;c++)if(canPlace(s,r,c))n++;return n;}
    private int clearFullLines(){int cleared=0;boolean[] rows=new boolean[N],cols=new boolean[N];for(int r=0;r<N;r++){rows[r]=true;for(int c=0;c<N;c++)rows[r]&=cells[r][c];}for(int c=0;c<N;c++){cols[c]=true;for(int r=0;r<N;r++)cols[c]&=cells[r][c];}for(int r=0;r<N;r++)if(rows[r]){cleared++;for(int c=0;c<N;c++)cells[r][c]=false;}for(int c=0;c<N;c++)if(cols[c]){cleared++;for(int r=0;r<N;r++)cells[r][c]=false;}return cleared;}
}
