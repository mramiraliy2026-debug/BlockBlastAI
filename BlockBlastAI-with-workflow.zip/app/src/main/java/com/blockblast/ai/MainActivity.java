package com.blockblast.ai;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.provider.Settings;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{
    TextView status; Button start,stop,access;
    @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,40,32,32); TextView title=new TextView(this);title.setText("Block Blast AI V2");title.setTextSize(28);title.setTextColor(Color.BLACK); root.addView(title); status=new TextView(this);status.setText("برای شروع، Accessibility را فعال کن.");status.setTextSize(16);root.addView(status); access=new Button(this);access.setText("فعال‌سازی Accessibility");root.addView(access);start=new Button(this);start.setText("شروع Auto Play");root.addView(start);stop=new Button(this);stop.setText("توقف فوری");root.addView(stop);setContentView(root);
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        start.setOnClickListener(v->{BlastAccessibilityService s=BlastAccessibilityService.getInstance();if(s!=null){s.startAuto();status.setText("Auto Play فعال است");}else status.setText("ابتدا سرویس Accessibility را فعال کن.");});
        stop.setOnClickListener(v->{BlastAccessibilityService s=BlastAccessibilityService.getInstance();if(s!=null)s.stopAuto();status.setText("متوقف شد");});
    }
}
