package com.blockblast.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.Gravity;
import android.widget.TextView;
import android.graphics.Color;
import java.util.*;

public class BlastAccessibilityService extends AccessibilityService {
    private static BlastAccessibilityService instance; private final Handler handler=new Handler(Looper.getMainLooper()); private TextView overlay; private boolean running;
    public static BlastAccessibilityService getInstance(){return instance;}
    @Override public void onServiceConnected(){super.onServiceConnected();instance=this;showOverlay("Block Blast AI آماده");}
    @Override public void onDestroy(){running=false;hideOverlay();instance=null;super.onDestroy();}
    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e){}
    @Override public void onInterrupt(){running=false;}
    public void startAuto(){running=true;showOverlay("AUTO فعال • توقف فوری: دکمه Stop");capture();}
    public void stopAuto(){running=false;showOverlay("متوقف شد");}
    private void capture(){if(!running||Build.VERSION.SDK_INT<30)return;takeScreenshot(0, getMainExecutor(), new TakeScreenshotCallback(){public void onSuccess(ScreenshotResult r){Bitmap b=Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(),r.getColorSpace()); if(b!=null){b=b.copy(Bitmap.Config.ARGB_8888,false); Board board=Vision.readBoard(b,0,0,Math.min(b.getWidth(),b.getHeight())); List<Move> moves=new Solver().solve(board,Vision.demoPieces()); if(!moves.isEmpty()) showOverlay("بهترین حرکت: قطعه "+(moves.get(0).piece+1)+" → "+moves.get(0).row+","+moves.get(0).col); b.recycle();} if(r.getHardwareBuffer()!=null)r.getHardwareBuffer().close(); if(running)handler.postDelayed(()->capture(),700);}
        public void onFailure(int e){if(running)handler.postDelayed(()->capture(),1000);}});}
    private void showOverlay(String s){handler.post(()->{if(overlay==null){overlay=new TextView(this);overlay.setTextColor(Color.WHITE);overlay.setTextSize(14);overlay.setPadding(22,12,22,12);overlay.setBackgroundColor(0xCC202020);WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;p.y=80;getSystemService(WindowManager.class).addView(overlay,p);}overlay.setText(s);});}
    private void hideOverlay(){handler.post(()->{if(overlay!=null){((WindowManager)getSystemService(WINDOW_SERVICE)).removeView(overlay);overlay=null;}});}
    public void gesture(float x1,float y1,float x2,float y2,long duration){Path p=new Path();p.moveTo(x1,y1);p.lineTo(x2,y2);dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,duration)).build(),null,null);}
}
