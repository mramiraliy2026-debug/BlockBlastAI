package com.blockblast.ai;
import java.util.*;
public final class Shape {
    public final int[][] cells;
    public Shape(int[][] p){cells=p;}
    public int size(){return cells.length;}
    public static Shape normalize(boolean[][] m){int minR=99,minC=99,maxR=-1,maxC=-1;for(int r=0;r<m.length;r++)for(int c=0;c<m[r].length;c++)if(m[r][c]){minR=Math.min(minR,r);minC=Math.min(minC,c);maxR=Math.max(maxR,r);maxC=Math.max(maxC,c);}if(maxR<0)return new Shape(new int[0][2]);int[][] p=new int[(maxR-minR+1)*(maxC-minC+1)][2];int k=0;for(int r=minR;r<=maxR;r++)for(int c=minC;c<=maxC;c++)if(m[r][c]){p[k][0]=r-minR;p[k++][1]=c-minC;}return k==p.length?new Shape(p):new Shape(Arrays.copyOf(p,k));}
}
