package com.blockblast.ai;
public final class Move { public final int piece,row,col; public Move(int piece,int row,int col){this.piece=piece;this.row=row;this.col=col;} }
